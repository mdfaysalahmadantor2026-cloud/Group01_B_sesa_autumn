const API='../backend/api/';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stars=n=>'<span class="star">'+'★'.repeat(Math.round(n))+'☆'.repeat(5-Math.round(n))+'</span>';
const $=id=>document.getElementById(id);
function toast(m,ok=true){const t=document.createElement('div');t.className='toast '+(ok?'ok':'err');t.textContent=m;document.body.append(t);setTimeout(()=>t.remove(),3200);}
async function api(f,body){try{const r=await fetch(API+f,{method:body?'POST':'GET',credentials:'include',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const j=await r.json();return j;}catch(e){return{success:false,message:'Network or server error'};}}
const load=el=>{el.innerHTML='<div class="load">Loading…</div>'};
const list=(a,fn,empty)=>a&&a.length?a.map(fn).join(''):`<div class="empty">${esc(empty)}</div>`;
async function act(file,body,ok){const r=await api(file,body);toast(r.message||(r.success?'Done':'Failed'),r.success);return r;}
async function init(){
const page=location.pathname.split('/').pop().replace('.html','')||'index';
const r=await api('me.php');const u=r.success?r.data:null;
if(!u&&!['index','login','register'].includes(page)){location='login.html';return null;}
if(page==='admin'&&u?.role!=='admin'){location='dashboard.html';return null;}
const L=u?[['dashboard','Dashboard'],['browse','Browse'],['requests','Requests'],['sessions','Sessions'],['schedule','Schedule'],['reviews','Reviews'],['notifications','Alerts'+(u.unread?`<span class="badge">${u.unread}</span>`:'')],['profile','Profile']].concat(u.role==='admin'?[['admin','Admin']]:[]):[['login','Log in'],['register','Sign up']];
$('nav').innerHTML='<a class="brand" href="index.html">🌿 SkillSwap</a>'+L.map(l=>`<a href="${l[0]}.html">${l[1]}</a>`).join('')+(u?'<a href="#" id="lo">Logout</a>':'');
if(u)$('lo').onclick=async e=>{e.preventDefault();await api('logout.php',{});location='login.html';};
return u;}
