init();$('go').onclick=async()=>{const r=await act('login.php',{email:$('email').value,password:$('pw').value});if(r.success)location='dashboard.html';};
